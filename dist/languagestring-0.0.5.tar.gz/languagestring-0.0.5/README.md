# languagestring


<strong> To use: </strong>

<p> from languagestring import languagestring </p>
<p>ls = languagestring()</p>
<p> # get czech characters </p>
<p>ls.language_string('cz')</p>
<p>'áčďéěíňóřšťúůýž'</p>


<strong>Working Languages: </strong>
<p> {
	"se" : "swedish",
	"fr" : "french",
	"de" : "german",
	"nl" : "dutch",
	"es" : "spanish",
	"pt" : "portuguese",
	"pl" : "polish",
	"cz" : "czech",
	"it" : "italian"
}</p>

